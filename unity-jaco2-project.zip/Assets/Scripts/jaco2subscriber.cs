using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.Robotics.ROSTCPConnector;
using JointStateMsg = RosMessageTypes.Sensor.JointStateMsg;

public class jaco2subscriber : MonoBehaviour
{
    public ArticulationBody joint1;
    public ArticulationBody joint2;
    public ArticulationBody joint3;
    public ArticulationBody joint4;
    public ArticulationBody joint5;
    public ArticulationBody joint6;
    public ArticulationBody joint7;

    private ArticulationBody[] joint;
    private ROSConnection ros;


    // Start is called before the first frame update
    void Start()
    {
        ros = ROSConnection.GetOrCreateInstance();
        ros.Subscribe<JointStateMsg>("/j2s7s300_driver/out/joint_state", Callback);

        joint = new ArticulationBody[7];
        joint[0] = joint1;
        joint[1] = joint2;
        joint[2] = joint3;
        joint[3] = joint4;
        joint[4] = joint5;
        joint[5] = joint6;
	joint[6] = joint7;
    }

    void Callback(JointStateMsg msg)
    {
        for (int i = 0; i < 7; i++)
        {
            ArticulationDrive aDrive = joint[i].xDrive;
            aDrive.target = Mathf.Rad2Deg * (float)msg.position[i];
            joint[i].xDrive = aDrive;
        }
    }
}
